from src.data.load_data import load_financial_data
from src.data.preprocess_data import preprocess_data
from src.models.train_model import train_model
from src.models.evaluate_model import evaluate_model
from src.visualization.plots import plot_revenue

def main():
    # Load data
    raw_data_path = 'data/raw/Bureau_Veritas_Financials.csv'
    data = load_financial_data(raw_data_path)

    # Preprocess data
    data = preprocess_data(data)

    # Train model
    model, X_test, y_test, y_pred = train_model(data)

    # Evaluate model
    evaluate_model(y_test, y_pred)

    # Plot results
    plot_revenue(y_test, y_pred)

if __name__ == "__main__":
    main()
