import matplotlib.pyplot as plt

def plot_revenue(y_test, y_pred):
    plt.plot(y_test.index, y_test, label='Actual')
    plt.plot(y_test.index, y_pred, label='Predicted')
    plt.legend()
    plt.title('Revenue Forecast')
    plt.xlabel('Date')
    plt.ylabel('Revenue')
    plt.show()
